//botinfo//

interval(1);

var i = msg.author.id;
if (i == '132196978003017729' || i == '131296127285723137') {
    var l = [];
    var shds = client.ws.shards.array();
    for (var i = 0; i < shds.length;i++) {
        var shrd = shds[i];
        l.push(`
        \`${shards[shrd.id]}\`
        ⤷ ping: ${shrd.ping}ms`);
    }
    msg.channel.send({embed: Embed({
        title:'Painel de controle',
        description:`**Servidores:** ${client.guilds.cache.size}\n**Usuários:** ${client.users.cache.size}\n**Shards:**${l.join('\n')}`
    })});
}