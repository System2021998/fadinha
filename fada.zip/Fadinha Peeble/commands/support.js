//suporte,denunciar,denuncia//

interval(2);

msg.lineReplyNoMention(Embed({
    description:`Sugestões, dúvidas e denúncias aqui no link:\n[Servidor de suporte](https://top.gg/servers/846897263753035826/join/)`
}));