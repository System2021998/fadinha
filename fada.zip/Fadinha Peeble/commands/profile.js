//perfil,info,badges//

interval(5);

function haveId(array,id) {
    var have = false;
    for (var i = 0; i < array.length; i++) {
        var role = array[i];
        if (role.id == id) {
            have = true;
            break;
        }
    }
    return have;
}

async function tf(badges,user){
    if(!badges) badges = '[]';
    badges = JSON.parse(badges);
    if (user.flags.toArray().includes('HOUSE_BALANCE')) badges.push('./website/badges/balance.png')
    if (user.flags.toArray().includes('HOUSE_BRILLIANCE')) badges.push('./website/badges/brilliance.png')
    if (user.flags.toArray().includes('HOUSE_BRAVERY')) badges.push('./website/badges/bravery.png')
    try {
        var member = await client.guilds.cache.get('846897263753035826').members.fetch(user.id);
        if (haveId(member.roles.cache.array(),'847268924927508531')) badges.push('./website/badges/bughunter1.png');
        if (haveId(member.roles.cache.array(),'848187674539851796')) badges.push('./website/badges/bughunter2.png');
        if (haveId(member.roles.cache.array(),'854361861503975445')) badges.push('./website/badges/staff.png');
        if (haveId(member.roles.cache.array(),'867656435042091028')) badges.push('./website/badges/dev.png')
    } catch(e) {
        console.log(e)
    }
    var d = await JSON.stringify(badges);
    return d;
}

async function as() {
    var user = await getUserInArgs(msg.content,msg,true,false);
    if (!user) return msg.channel.send(`${member} Vish, não achei nenhum usuário com isso ai que você mandou kkksk.`);
    var rsql = await SQLdata(user.id);
    if (!rsql[0]) {
        rsql[0] = {};
    }
    var badgesO = !rsql[0] ? '[]' : rsql[0].badges;
    var bd = await tf(badgesO,user);
    var badges = b64_encode(bd);
    var bg = !rsql[0].background ? '' : '&bg=' + rsql[0].background;
    var aboutme = b64_encode(!rsql[0].aboutme ? 'Você pode alterar esse texto usando -Sobremim' : rsql[0].aboutme);
    var curl = encodeURI('https://fadinha.site/canvas/profile.png?key=XDkmSiJASDNAix191j230XMAax0AlxMZ&badges=' + badges + '&avatar=' + user.displayAvatarURL({format: 'png'}).replace('https://cdn.discordapp.com/','https://media.discordapp.net/') + '&tag=' + user.tag.split('#').join('()') + bg + '&aboutme=' + aboutme);
    try {
        var f = await fetch(curl);
        var buff = await f.buffer();
        var attachment = new Discord.MessageAttachment(buff,'profile.png');
        msg.channel.send(`${member}`,attachment);
    } catch(err) {
        msg.channel.send(`${member}\n> Desculpe! Ocorreu um erro no comando.`);
    }
}

as();