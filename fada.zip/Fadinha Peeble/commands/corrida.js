//race//

interval(1);

async function asy() {
    var max = 15;
    var value = 0;
    var win = 0;
    var ended = false;
    if (args.length === 2) {
        var qtd = vqtd(args[1]);
        if (isNaN(qtd)) {
            return msg.lineReply(`${member} :sweat_smile: eita..\n> A quantia não é um número!`);
        }
        if (qtd <= 1) {
            return msg.lineReply(`${member} :sweat_smile: eita..\n> A quantia precisa ser 2 ou mais.`);
        }
        if (qtd > 16) {
            return msg.lineReply(`${member} :sweat_smile: eita..\n> A quantia precisa ser 15 ou menos.`);
        }
        max = qtd;
    } else if (args.length >= 3) {
        if (args[1] == 'bet' || args[1] == 'apostar') {
            var qtd = vqtd(args[2]);
            if (isNaN(qtd)) {
                return msg.lineReply(`${member} :sweat_smile: eita..\n> A quantia não é um número!`);
            }
            if (qtd <= 0) {
                return msg.lineReply(`${member} :sweat_smile: eita..\n> A quantia precisa ser 1 ou mais.`);
            }
            if (msg.author.data.moeldas < qtd) {
                return msg.lineReply(`${member} :sweat_smile: eita..\n> Você não tem moeldas suficiente.`);
            }
            value = Number(qtd);
            win = value;
            await con.execute(`UPDATE customer_202582_fadinha.users SET moeldas=moeldas-'${value}' WHERE id='${msg.author.id}' LIMIT 1;`);
            await addTransaction(msg.author.id,`📤 Enviou ${Number(value).toLocaleString('pt-br')} moeldas para criar corrida`);
        }
        if (args.length >= 4) {
            var qtdm = vqtd(args[3]);
            if (!isNaN(qtdm)) {
                if (qtdm >= 2) {
                    if (qtdm < 16) {
                        max = qtdm;
                    }
                }
            }
        }
    }
    function display(arr) {
        var dsp = [];
        for (var i = 0; i < arr.length; i++) {
            dsp.push(`${arr[i][1]} ${arr[i][0]} | ${arr[i][2]}`);
        }
        return dsp.join('\n');
    }
    var cars = '<:marioyoshi:868483510585917470>,<:truck:868447129834778654>,<:taxi:868447129595682866>,<:pulissia:868447129994133515>,<:moto:868447129797001256>,<:lesma:868447129755058217>,<:kombi:868447129604083733>,<:uno:868669045313003521>,<:alazao:868447129293709322>,<:fusca:868447129637650482>,<:flash:868447129050447893>,<:ferrari:868447129474048070>,<:carlinha:868447129629257748>,<:camaro:868447129268518913>,<:busao:868447129838977045>,<:bmw:868447129536974938>,<:corsinha:850542527499993088>'.split(',');
    var carsname = 'Yoshi Corridão,Truck Boladão,Táxi Rapidex,Viatura SOS,Motinha Potente,Lesma Turbo,Kombi Vibes,Fiat Uno aro 16,Cavalo Alazão,Fusca Rebaixado,Flash Vrumm,Uber Ferrari,Tartaruga Vapo,Camaro XXT,Busão Lotado,BMW Tubinada,Corsa Rebaixado'.split(',')
    var users = [];
    var hr = false;
    var rnd = rand(0, cars.length - 1);
    users.push([msg.author, cars[rnd], carsname[rnd]]);
    cars.splice(rnd,1);
    carsname.splice(rnd,1);
    let btn = new MessageButton()
    .setLabel("Iniciar")
    .setStyle("grey")
    .setEmoji("✅")
    .setID("iniciar");
    let btn2 = new MessageButton()
    .setLabel("Participar")
    .setStyle("grey")
    .setEmoji("🏁")
    .setID("congelar");
    var row = new disbut.MessageActionRow()
    .addComponent(btn)
    .addComponent(btn2);
    var obj = await msg.channel.send({embed: Embed({
        color:'#42a4f5',
        title:'🚦 Corrida',
        description:`**Preço para entrar na corrida**: ${value === 0 ? 'é apenas uma corrida, sem valer nada!' : Number(value).toLocaleString('pt-br') + ' Moeldas'}
**Prêmio atual:** ${win === 0 ? 'Nada' : Number(win).toLocaleString('pt-br') + ' Moeldas'}
**Quer entrar na corrida?** Clique no botão de participar! *Máximo ${max} pessoas*
O resultado da corrida irá sair quando ${msg.author} Iniciar ou após 1 minuto.
        
**(${users.length}) Participante(s):**
${display(users)}`
    }), component: row});
    function inList(id) {
        var inl = false;
        for (var i = 0; i < users.length;i++) {
            if (users[i][0].id == id) {
                inl = true;
            }
        }
        return inl;
    }
    async function round() {
        async function end() {
            if (users.length === 1) {
                if(value > 0) {
                    con.execute(`UPDATE customer_202582_fadinha.users SET moeldas=moeldas+'${value}' WHERE id='${msg.author.id}' LIMIT 1;`);
                    await addTransaction(msg.author.id,`🔄 ${Number(win).toLocaleString('pt-br')} Moeldas estornados na corrida por falta de usuários.`);
                }
                hr = true;
                return msg.lineReply(`${msg.author} Só tinha você na corrida, então foi encerrada! <:tuto:868960489206579290>`);
            }
            var winner = users[rand(0,users.length)];
            if (value > 0) {
                await con.execute(`UPDATE customer_202582_fadinha.users SET moeldas=moeldas+'${win}' WHERE id='${winner[0].id}' LIMIT 1;`);
                await addTransaction(winner[0].id,`📥 Ganhou ${Number(win).toLocaleString('pt-br')} moeldas na corrida de ${msg.author.tag} | \`${msg.author.id}\``);
            }
            if (winner[0].id != msg.author.id && value > 0) {
                await addTransaction(msg.author.id,`📤 Perdeu ${Number(value).toLocaleString('pt-br')} moeldas em sua corrida para ${winner[0].tag} | \`${winner[0].id}\``);
            }
            msg.channel.send(`> **${winner[2]}** ${winner[1]} de ${winner[0]} ganhou ${value > 0 ? `**${p(win)}** Moeldas n`:''}a corrida de ${msg.author}`);
            hr = true;      
            if (value > 0) {
                var dn = new Date();
                var timestamp = `\`[${dn.getDate()}/${dn.getMonth() + 1}/${dn.getFullYear()} ${tw(dn.getHours())}:${tw(dn.getMinutes())}]\``;
                client.hook5.send(`\`${timestamp}\` ${winner[0]} | \`${winner[0].id}\` recebeu **${Number(win).toLocaleString('pt-br')}** na corrida de ${msg.author} | \`${msg.author.id}.\``);
            }
        }
        setTimeout(async function() {
            if (!hr) {
                return end();
            }
        },61000);
        
        const Pfilter = async (button) => {
            var u = !button.clicker.member ? button.clicker.user : button.clicker.member.user;
            if (!exhaust(300)) return false;
            if (button.id == 'iniciar' && !ended) {
                if (u.id !== msg.author.id) return false;
                ended = true;
                await end();
                await button.clicker.fetch();
                return false;
            } else if(ended) {
                return false;
            }
            if (inList(u.id)) return false;
            var rsql = await SQLdata(u.id);
            if (!rsql[0] || rsql[0].moeldas < value) {
                if (!exhaust(3500,u.id)) return false;
                await button.clicker.fetch();
                return false;
            }
            var rnd = rand(0, cars.length - 1);
            users.push([u, cars[rnd], carsname[rnd]]);
            cars.splice(rnd,1);
            carsname.splice(rnd,1);
            if (value > 0) {
                await con.execute(`UPDATE customer_202582_fadinha.users SET moeldas=moeldas-'${value}' WHERE id='${u.id}' LIMIT 1;`);
                addTransaction(u.id,`📤 Enviou ${Number(value).toLocaleString('pt-br')} moeldas na corrida de ${msg.author.tag} | \`${msg.author.id}\``);
                win = Number(win) + value;
            }
            obj.edit({embed: Embed({
                color: '#42a4f5',
                title: '🚦 Corrida',
                description:`**Preço para entrar na corrida**: ${value === 0 ? 'é apenas uma corrida, sem valer nada!' : Number(value).toLocaleString('pt-br') + ' Moeldas'}
**Prêmio atual:** ${win === 0 ? 'Nada' : Number(win).toLocaleString('pt-br') + ' Moeldas'}
**Quer entrar na corrida?** Clique no botão de participar! *Máximo ${max} pessoas*
O resultado da corrida irá sair quando ${msg.author} Iniciar ou após 1 minuto.

**(${users.length}) Participantes:**
${display(users)}
            `}), component: row});
            await button.clicker.fetch();
            return true;
        }

        try {
            await obj.awaitButtons(Pfilter, {max: max - 1, time: 60000 });
            if (obj.deleted) return;
            if (ended) return;
            return end();
        } catch(err) {
            console.log(err);
        }
    }
    round();
}
    
if (!needToDaily(msg.author)) {
    msg.lineReply(`> ${member} Você precisa resgatar o daily para iniciar uma corrida.\n> Pra resgatar acesse nosso site:\n> https://fadinha.site/daily`);
} else {
    asy();
}