//carteira,banco,ct,moeldas,fcoins,bal//

interval(2);

async function as() {
    var user = await getUserInArgs(msg.content,msg,true);
    if (!user) return msg.channel.send(`${member} Eita, não consegui encontrar por nenhum usuário no comando!`);
    var rsql;
    if (user.id == msg.author.id) {
        rsql = [msg.author.data];
    } else {
        rsql = await SQLdata(user.id);
    }
    if (!rsql[0]) {
        rsql[0] = {moeldas: 0};
    }
    msg.lineReply(Embed({
        color:'#9a60eb',
        Author: '{user},{user.avatar}',
        description: `**Saldo de** ${user}
<:fadaMoeldas:846746239806865408> **${rsql[0].moeldas.toLocaleString('en')}** Moeldas
<:Fcoin:851854139574190140> **${rsql[0].fcoins}** Fcoins`
        })
    );
}

as();