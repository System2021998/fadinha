//ftop,fleaderboard//

interval(2);

async function as() {
    var [ top ] = await con.execute(`SELECT * FROM users ORDER BY fcoins DESC LIMIT 5;`);
    var display = [];
    for (var i = 0; i < top.length; i++) {
        try {
            var user = await client.users.fetch(top[i].id);
            display.push(`${i + 1}. ${user.tag} ▸ **${Number(top[i].fcoins).toLocaleString('pt-br')}**`);
        } catch(err) { console.log('Erro no comando -frank'); }
    }
    msg.lineReply(Embed({
        title:'Top 5 <:Fcoin:851854139574190140> FCoins',
        description: display.join("\n"),
        color:'9460fc'
    }));
}

as();