//sorte,rifs//

interval(2);

async function asn() {
    if(!globalDB.data['rtickets']) globalDB.store('rtickets',[]);
    if(!globalDB.data['rusers']) globalDB.store('rusers',[]);
    if(!globalDB.data['rdate']) globalDB.store('rdate', Date.now() + 3600000);
    if(!globalDB.data['rlastwinner']) globalDB.store('rlastwinner','Nenhum até agora!');
    if(!globalDB.data['rlastwinnerid']) globalDB.store('rlastwinnerid', '');
    if(!globalDB.data['rlastprize']) globalDB.store('rlastprize',0);

    if (!(args[1] && args[1] == 'buy' || args[1] && args[1] == 'comprar')) {
        var tl = globalDB.data['rdate'] - Date.now();
        msg.channel.send(`${member} **Rifa Manera (✿ʘ ᴗʘ)っ━✫**
💵 Prêmio acumulado: **${p(globalDB.data['rtickets'].length * 190)} Moeldas**
🎫 Tickets comprados: **${globalDB.data['rtickets'].length} Tickets**
👥 Participantes: **${globalDB.data['rusers'].length} Pessoa(s)**
:moneybag: Último ganhador: \`${globalDB.data['rlastwinner'].split('`').join('').split('**').join('')} (${globalDB.data['rlastwinnerid']})\` **(${p(globalDB.data['rlastprize'])} Moeldas)**
⏰ O resultado irá sair em **${prettyMilliseconds((tl < 0 ? 0 : tl))}**
<:moelda:868455091169017866> Cada ticket custa 200 Moeldas.
Caso queira comprar, use \`-rifa comprar (quantidade)\`!
        `);
    } else {
        if (!needToDaily(msg.author)) {
            msg.channel.send(`> ${member} Você precisa resgatar o daily para comprar tickets.\n> Pra resgatar acesse nosso site:\n> https://fadinha.site/daily`);
        } else {
            if (args.length <= 2) {
                return msg.channel.send(`${member}\n> Uso do comando: \`-rifa buy (quantia)\``);
            }
            var qtd = vqtd(args[2]);
            if (isNaN(qtd)) {
                return msg.channel.send(`${member} :sweat_smile: eita..\n> A quantia não é um número!`);
            }
            if (qtd <= 0) {
                return msg.channel.send(`${member} :sweat_smile: eita..\n> A quantia precisa ser maior que 1.`);
            }
            if (qtd > 1000) {
                return msg.channel.send(`${member} :sweat_smile: eita..\n> A quantia precisa ser menor que 1000.`);
            }
            if (msg.author.data.moeldas < (qtd * 200)) {
                return msg.channel.send(`${member} **A quantidade de moeldas precisa ser válida.**\n> Falta **${((qtd * 200) - msg.author.data.moeldas).toLocaleString('en')}** Moeldas para comprar **${qtd}** tickets.`);
            }
            var temprTickets = temp(globalDB.data['rtickets']);
            var temprUsers = temp(globalDB.data['rusers']);
            var qtdi = getCountByItem(temprTickets,msg.author.id);
            if (qtdi > 3000) {
                return msg.channel.send(`${member} **Limite atingido**\n> Você atingiu a quantia de **3,000** tickets na rifa.`);
            }
            for (let i = 0; i < qtd; i++) {
                temprTickets.push(msg.author.id);
            }
            if (temprUsers.indexOf(msg.author.id) < 0) {
                temprUsers.push(msg.author.id);
            }

            globalDB.data['rtickets'] = temprTickets;
            globalDB.data['rusers'] = temprUsers;
            globalDB.storeAll();
            client.hook3.send(`💸 ${msg.author} | \`${msg.author.id}\` enviou ${qtd * 190} moeldas na rifa.`);
            await con.execute(`UPDATE customer_202582_fadinha.users SET moeldas=moeldas-'${(qtd * 200)}' WHERE id='${msg.author.id}' LIMIT 1;`);
            msg.channel.send(`${member} **Rifadinha!**\n> Você comprou **${qtd}** Ticket(s) por **${qtd * 200}** Moeldas.`);
            await addTransaction(msg.author.id,`📤 Enviou ${qtd} tickets (${qtd * 200} moeldas) para a rifa.`);
        }
    }
}

asn();