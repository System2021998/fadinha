interval(3);

function wt(array,wto) {
    var arr = JSON.parse(JSON.stringify(array));
    for (var i = 0; i < arr.length; i++) {
        if (arr[i] == wto) {
            delete arr[i];
        }
    }
    return arr;
}

async function as() {
    if (args.length < 2) return msg.channel.send(`${member}\n> Uso do comando: \`-lisa meu texto aqui\``);
    try {
        var f = await fetch('https://fadinha.site/canvas/margie.png?key=oXMZlao103kZXMakls1001lsXM&url=' + wt(args,args[0]).join(' '));
        var buff = await f.buffer();
        var attachment = new Discord.MessageAttachment(buff,'lisa.png');
        msg.channel.send(`${member}`,attachment);
    } catch(err) {
        msg.channel.send(`${member}\n> Desculpe! Ocorreu um erro no comando.`);
    }
}

as();