//slots,caçaniquel//

interval(4);

async function as() {
    var qtd = vqtd(args[1]);
    if (isNaN(qtd)) {
        return msg.lineReply(`${member} :sweat_smile: eita..\n> A quantia não é um número!`);
    }
    if (qtd < 50) {
        return msg.lineReply(`${member} :sweat_smile: eita..\n> A quantia precisa ser maior ou igual à 50.`);
    }
    if (qtd > 6000) {
        return msg.lineReply(`${member} :sweat_smile: eita..\n> A quantia precisa ser menor ou igual à 6000!`);
    }
    if (msg.author.data.moeldas < qtd) {
        return msg.lineReply(`${member} :sweat_smile: eita..\n> Você não tem moeldas suficiente.`);
    }
    qtd = Math.floor(qtd);
    if (!exhaust()) return;
    await con.execute(`UPDATE customer_202582_fadinha.users SET moeldas=moeldas-'${qtd}' WHERE id='${msg.author.id}' LIMIT 1;`);
    var cbn = `${rand(1,7)}${rand(1,7)}${rand(1,7)}`;
    var win = rand(0.54,0.66);
    if (cbn == '111') win = 1.3
    if (cbn == '222') win = 1.4
    if (cbn == '333') win = 1.5
    if (cbn == '444') win = 1.6
    if (cbn == '555') win = 1.8
    if (cbn == '666') win = 8
    if (cbn == '112' || cbn == '121' || cbn == '211') win = 1.11
    if (cbn == '113' || cbn == '131' || cbn == '311') win = 1.11
    if (cbn == '114' || cbn == '141' || cbn == '411') win = 1.11
    if (cbn == '115' || cbn == '151' || cbn == '511') win = 1.11
    if (cbn == '116' || cbn == '161' || cbn == '611') win = 1.38
    //
    if (cbn == '221' || cbn == '212' || cbn == '122') win = 1.2
    if (cbn == '223' || cbn == '232' || cbn == '322') win = 1.2
    if (cbn == '224' || cbn == '242' || cbn == '422') win = 1.2
    if (cbn == '225' || cbn == '252' || cbn == '522') win = 1.2
    if (cbn == '226' || cbn == '262' || cbn == '622') win = 1.7
    //
    if (cbn == '331' || cbn == '313' || cbn == '133') win = 1.3
    if (cbn == '332' || cbn == '323' || cbn == '233') win = 1.3
    if (cbn == '334' || cbn == '343' || cbn == '433') win = 1.3
    if (cbn == '335' || cbn == '353' || cbn == '533') win = 1.3
    if (cbn == '336' || cbn == '363' || cbn == '633') win = 1.8
    //
    if (cbn == '441' || cbn == '414' || cbn == '144') win = 1.4
    if (cbn == '442' || cbn == '424' || cbn == '244') win = 1.4
    if (cbn == '443' || cbn == '434' || cbn == '344') win = 1.4
    if (cbn == '445' || cbn == '454' || cbn == '544') win = 1.4
    if (cbn == '446' || cbn == '464' || cbn == '644') win = 1.4
    //
    if (cbn == '551' || cbn == '515' || cbn == '155') win = 1.4
    if (cbn == '552' || cbn == '525' || cbn == '255') win = 1.4
    if (cbn == '553' || cbn == '535' || cbn == '355') win = 1.6
    if (cbn == '554' || cbn == '545' || cbn == '455') win = 1.6
    if (cbn == '556' || cbn == '565' || cbn == '655') win = 2.2
    //
    if (cbn == '661' || cbn == '616' || cbn == '166') win = 2.8
    if (cbn == '662' || cbn == '626' || cbn == '266') win = 2.0
    if (cbn == '663' || cbn == '636' || cbn == '366') win = 2.2
    if (cbn == '664' || cbn == '646' || cbn == '466') win = 2.3
    if (cbn == '665' || cbn == '656' || cbn == '566') win = 2.9
    var obj = await msg.lineReply(Embed({
        title:'🎰 Girando slot...',
        color:'RANDOM',
        image: 'https://i.ibb.co/QkpYmFy/ezgif-6-e25a15352c35.gif',
        footer: {text:`Enviado por ${msg.author.tag} | Valendo ${qtd} Moeldas`,icon_url:msg.author.displayAvatarURL()}
    }));
    setTimeout(async function() {
        await con.execute(`UPDATE customer_202582_fadinha.users SET moeldas=moeldas+'${Math.round(qtd * win)}' WHERE id='${msg.author.id}' LIMIT 1;`);
        obj.edit({embed:Embed({
            title:'🎰 Slot finalizado!',
            color:'RANDOM',
            image: 'https://fadinha.site/canvas/slot.jpg?var=' + cbn,
            description: `${win > 5 ? '🎉 **JACKPOT!** Meus parabéns!\n*Sabia que você só tinha 0,5% de chance e conseguiu!?*' : ''}\n${member}\nDe **${qtd}** Moeldas, você recebeu **${Math.round(qtd * win)}** de volta!`,
            footer: {text:`Slots de ${msg.author.tag}`,icon_url:msg.author.displayAvatarURL()}
        })});
        var winned = Math.round(qtd * win);
        if (winned > qtd) {
            await addTransaction(msg.author.id,`📥 Recebeu ${winned - qtd} moeldas em slot.`);
        } else {
            await addTransaction(msg.author.id,`📤 Perdeu ${qtd - winned} moeldas no slot.`);
        }
    },2000);
}

as();