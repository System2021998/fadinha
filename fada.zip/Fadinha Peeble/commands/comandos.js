interval(2);

msg.lineReply(Embed({
    title:'',
    color:'RANDOM',
    description: `${member}
Aqui você encontra a lista completa das minhas funcionalidades.
<:biblioteca:862907344732028938> https://fadinha.site/comandos`
}));