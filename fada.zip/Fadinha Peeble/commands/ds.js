userDB.store(msg.author.id,'inbj','false');
userDB.store(userDB.get(msg.author.id,'lbu'),'inbj','false')