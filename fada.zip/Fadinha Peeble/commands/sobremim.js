//aboutme,biografia//

interval(3);

function wt(array,wto) {
    var arr = JSON.parse(JSON.stringify(array));
    for (var i = 0; i < arr.length; i++) {
        if (arr[i] == wto) {
            delete arr[i];
        }
    }
    return arr;
}

async function as() {
    if (args.length < 2) return msg.channel.send(`${member}\n> Uso do comando: \`-sobremim meu texto aqui\``);
    try {
        var chars = wt(args,args[0]).join(' ');
        if (chars.length > 250) return msg.channel.send(`${member} **Eita.. :sweat_smile:**\n> O máximo de caracteres são **250**!`);
        await con.execute(`UPDATE customer_202582_fadinha.users SET aboutme='${chars}' WHERE id='${msg.author.id}' LIMIT 1;`);
        msg.channel.send(`${member}\n> Informação alterada com **sucesso!**`);
    } catch(err) {
        msg.channel.send(`${member}\n> Desculpe! Ocorreu um erro no comando.`);
    }
}

as();