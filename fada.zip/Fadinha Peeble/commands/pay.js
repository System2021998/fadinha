//pagar,paypal,give,gift,doar,pix//

interval(2);

async function as() {
    var user = await getUserInArgs(msg.content,msg,false,false);
    if (!user) return msg.channel.send(`${member} Não consegui encontrar ninguém com esses digítos estranhos que você mandou, eu hein...:sweat_smile:`);
    var rsql = await SQLdata(msg.author.id);
    var rsql2 = await SQLdata(user.id);

    if (args.length <= 2) {
        return msg.channel.send(`${member}\n> Uso do comando: \`-pay @membro (quantia)\``);
    }

    var qtd = vqtd(args[2]);

    if (isNaN(qtd)) {
        return msg.channel.send(`${member} **Eita.. :sweat_smile:**\n> A quantia não é um número!`);
    }
    if (qtd <= 0) {
        return msg.channel.send(`${member} **Eita.. :sweat_smile:**\n> A quantia precisa ser maior que 1.`);
    }
    if (rsql[0].moeldas < qtd) {
        return msg.channel.send(`${member} **Eita.. :sweat_smile:**\n> Você não tem moeldas suficiente.`);
    }
    var obj = await msg.channel.send(`> ${user}, o usuário ${member} **Quer te enviar <:moelda:868455091169017866> ${Number(qtd).toLocaleString('pt-br')} Moeldas!**
    > Para confirmar a transação os dois devem reagir em ✅
    \`Aviso: Não somos responsáveis pelo uso indevido dos pagamentos. Todas as informações aqui em\` https://fadinha.site/regras.`);

    obj.react('✅');

    const filter = (reaction,u) => {
        return ['✅'].includes(reaction.emoji.name) && [msg.author.id,user.id].includes(u.id);
    };

    async function lp() {
        try {
            var reaction = await obj.awaitReactions(filter, { max: 1, time: 60000, errors: ['time'] })
            var rcs = reaction.get('✅').users.cache.array()
            function havIn(arr,id) {
                hav = false;
                for (var i =0; i < arr.length; i++) {
                    if (arr[i].id == id) {
                        hav = true;
                    }
                }
                return hav
            }

            if (!havIn(rcs,msg.author.id) || !havIn(rcs,user.id)) return lp();
            if (!exhaust(1500,msg.author.id)) return;
            if (!exhaust(1500,user.id)) return;
            rsql = await SQLdata(msg.author.id);
            if (rsql[0].moeldas < qtd) {
                return msg.channel.send(`${member} **Eita.. :sweat_smile:**\n> Você não tem mais moeldas suficiente.`);
            }

            await con.execute(`UPDATE users SET moeldas=moeldas-'${qtd}' WHERE id='${msg.author.id}' LIMIT 1;`);
            await addTransaction(msg.author.id,`💸 Enviou ${Number(qtd).toLocaleString('pt-br')} moeldas para ${user.tag} | \`${user.id}\``)
            await con.execute(`UPDATE users SET moeldas=moeldas+'${qtd}' WHERE id='${user.id}' LIMIT 1;`);
            await addTransaction(user.id,`💸 Recebeu ${Number(qtd).toLocaleString('pt-br')} moeldas de ${msg.author.tag} | \`${msg.author.id}\``)
            msg.channel.send(`${member} **enviou <:moelda:868455091169017866> ${Number(qtd).toLocaleString('pt-br')}** moeldas para ${user}.`)
            client.hook.send(`**${msg.author}** | \`${msg.author.id}\` Pagou: **${p(qtd)}** Para: **${user}** | \`${user.id}\``)
        } catch(err) {
            console.log(err);
            return;
        }
    }
lp();
}

if (msg.author.data.blacklist == 'true') {
    msg.reply("Você foi banido e não pode utilizar esse comando.");
} else if (!needToDaily(msg.author)) {
    msg.channel.send(`> ${member} Você precisa resgatar o daily para pagar alguém.\n> Pra resgatar acesse nosso site:\n> https://fadinha.site/daily`);
} else {
    as();
}