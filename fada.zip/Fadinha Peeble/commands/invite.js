//convite,add,adicionar,convidar//

interval(5);

msg.lineReply(Embed({
    color:'#00ffce',
    description: `${member}`,
    fields: [{
        name:'Quer me adicionar no seu servidor?',
        value:':white_check_mark: É só clicar aqui https://fadinha.site/add'
	}]
}));