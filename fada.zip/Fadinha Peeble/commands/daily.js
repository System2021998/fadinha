//diario,diário//

interval(5);

if (needToDaily(msg.author)) {
   var tl = prettyMilliseconds(Math.round((msg.author.data.timestamp - Date.now())));
   msg.lineReply(`> ${member}, Calma gata 
   > Tem que aguardar mais **${tl}** pra resgatar seu daily novamente
   > <:tuto1:850334222437711933><:tuto2:818111045285445632> eu hein... `); 
} else {
   msg.lineReply(`> ${member} Seu **daily** já está disponível! 
   > <a:baLao:818126680014585906> Resgata aqui: 
   > https://fadinha.site/daily`);
}