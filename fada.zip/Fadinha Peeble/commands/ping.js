//latencia,latência//

interval(2);

msg.channel.send(`${member} **Minha latência atual:**
> 🏓 Bot: \`${Math.round(client.ws.ping)}\`ms
> 📚 DB:  \`${dateSQL}\`ms
> 📡 Shard #${msg.guild.shardID} \`${shards[msg.guild.shardID]}\`
`);