//apostar,aposta//

interval(1);

async function as() {
    var user = await getUserInArgs(msg.content,msg,false,false);
    if (!user) return msg.lineReply(`${member} Não consegui encontrar por nenhum usuário no comando! Desculpe a intromissão.`);
    var rsql2 = await SQLdata(user.id);
    if (args.length <= 2) {
        return msg.lineReply(`${member}\n> Uso do comando: \`-bet @membro (quantia)\``);
    }
    var qtd = vqtd(args[2]);
    if (isNaN(qtd)) {
        return msg.lineReply(`${member} :sweat_smile: eita..\n> A quantia não é um número!`);
    }
    if (qtd <= 4) {
        return msg.lineReply(`${member} :sweat_smile: eita..\n> A quantia precisa ser maior que 4.`);
    }
    if (msg.author.data.moeldas < qtd) {
        return msg.lineReply(`${member} :sweat_smile: eita..\n> Você não tem moeldas suficiente.`);
    }
    if (rsql2[0].moeldas < qtd) {
        return msg.lineReply(`${member} :sweat_smile: eita..\n> O usuário não tem moeldas suficiente.`);
    }
    qtd = Math.round(qtd);
    var obj = await msg.lineReply(`${user}, ${member} Quer apostar <:moelda:868455091169017866> **${p(qtd)}** Moeldas com você.`, Embed({
        title:'Aposta',
        color:'#D0021B',
        thumbnail:'https://i.imgur.com/pS5sqOZ.png',
        description:`Jogue um dado de 6 lados!\nSe o dado cair **par**, **${user.username}** ganha!\nSe o dado cair **ímpar**, **${msg.author.username}** ganha!\n\nUsem 🎲 para aceitar/iniciar.`
    }));

    obj.react('🎲');
    const filter = (reaction,u) => {
        return ['🎲'].includes(reaction.emoji.name) && [msg.author.id,user.id].includes(u.id);
    }
    
    async function lp() {
        try {
            await obj.awaitReactions(filter, { max: 1, time: 60000, errors: ['time'] });
            var reaction = await obj.awaitReactions(filter, { max: 1, time: 60000, errors: ['time'] });
            var rcs = reaction.get('🎲').users.cache.array();
            function havIn(arr,id) {
                hav = false;
                for (var i =0; i < arr.length; i++) {
                    if (arr[i].id == id) {
                        hav = true;
                    }
                }
                return hav;
            }
            if (!havIn(rcs,msg.author.id) || !havIn(rcs,user.id)) return lp();
            if (!exhaust(60000,msg.author.id)) return;
            if (!exhaust(60000,user.id)) return;

            rsql = await SQLdata(msg.author.id);
            rsql2 = await SQLdata(user.id);

            if (rsql[0].moeldas < qtd) {
                return msg.lineReply(`${member} :sweat_smile: eita..\n> Você não tem mais moeldas suficiente.`);
            }
            if (rsql2[0].moeldas < qtd) {
                return msg.lineReply(`${member} :sweat_smile: eita..\n> O usuário não tem mais moeldas suficiente.`);
            }

            var dado = rand(1,7);
            var winner;
            var loser;
            var res;

            if (dado == 2 || dado == 4 || dado == 6) {
                winner = user;
                loser = msg.author;
                res = 'Par';
            } else {
                winner = msg.author;
                loser = user;
                res = 'Ímpar';
            }

            await con.execute(`UPDATE customer_202582_fadinha.users SET moeldas=moeldas-'${qtd}' WHERE id='${loser.id}' LIMIT 1;`);
            await con.execute(`UPDATE customer_202582_fadinha.users SET moeldas=moeldas+'${qtd}' WHERE id='${winner.id}' LIMIT 1;`);
            var dn = new Date();
            var timestamp = `\`[${dn.getDate()}/${dn.getMonth() + 1}/${dn.getFullYear()} ${tw(dn.getHours())}:${tw(dn.getMinutes())}]\``;
            client.hook2.send(`\`${timestamp}\` | ${winner} | \`${winner.id}\` Ganhou **${p(qtd)}** de ${loser} | \`${loser.id}\``);
            await addTransaction(loser.id,`📤 Perdeu ${p(qtd)} moeldas em aposta para ${winner.tag} | \`${winner.id}\``);
            await addTransaction(winner.id,`📥 Ganhou ${p(qtd)} moeldas em aposta de ${loser.tag} | \`${loser.id}\``);
            msg.lineReply(`> <:dado:868944955605934151> **${dado} ${res}**! Yay **${winner}** deu sorte!! recebeu <:moelda:868455091169017866> **${p(qtd)}** Moeldas de **${loser}**.`);
        } catch(err) {
            console.log(err);
            return;
        }
    }
    lp();
}

if (!needToDaily(msg.author)) {
    msg.lineReply(`> ${member} Você precisa resgatar o daily para apostar com alguém.\n> Pra resgatar acesse nosso site:\n> https://fadinha.site/daily`);
} else {
    as();
}