//trabalhar,trabalho//

interval(4);

async function as() {
    const workinterval = 21600000;
    if (msg.author.data.worktime > Date.now()) {
        var tl = prettyMilliseconds(msg.author.data.worktime - Date.now());
        msg.lineReply(`> ${member} **Calma..** <a:tutoQ:777776091023540246>
        > Descança um pouco, espera **${tl}** e volta aqui!
        > tô sem nenhum trampo pra você agora...`);
    } else {
        var win = rand(450,800);
        await con.execute(`UPDATE customer_202582_fadinha.users SET moeldas=moeldas+'${win}',fcoins=fcoins+'1',worktime=${Date.now()+workinterval} WHERE id='${msg.author.id}' LIMIT 1;`);
        msg.lineReply(Embed({
            color:'RANDOM',
            author: {name:msg.author.tag, icon_url:msg.author.displayAvatarURL({dynamic: true})},
            description:`Valeu o esforço... você recebeu
<:fadaMoeldas:846746239806865408> **${win}** Moeldas 
<:Fcoin:851854139574190140> **1** Fcoin 
Volte em :timer: **6 horas** 
Que tenho trampo pra você <:Dahora:777656985843007510>`
        }));
        await addTransaction(msg.author.id,`📥 Recebeu ${win} moeldas trabalhando.`);
    }
}

//if (!needToDaily(msg.author)) {
//   msg.lineReply(`> ${member} Você precisa resgatar o daily para trabalhar.\n> Pra resgatar acesse nosso site:\n> https://fadinha.site/daily`);
//} else {
    as();
//}