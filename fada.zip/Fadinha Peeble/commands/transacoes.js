//transações,transação,transations,histórico,historico,history,tr//

interval(5);

async function as() {
    var user = await getUserInArgs(msg.content,msg,true);
    if (!user) return msg.channel.send(`${member} Não consegui encontrar por nenhum usuário no comando! Desculpe a intromissão.`);

    var rsql = await SQLdata(user.id);

    if (!rsql[0] || !rsql[0].history) {
        return msg.channel.send(`${member} Histórico de transações vazio.`);
    }

    var us = rsql[0];
    var history = JSON.parse(b64_decode(us.history)).reverse();
    var pag = 10;
    var display = [];
    function update_pages() {
        display = history.slice(pag- 10,pag);
    }
    update_pages();
    var obj =  await msg.channel.send(Embed({
		color: 0x06dbfd,
        title:'Transações de ' + user.tag,
        description:`${display.join('\n')}`,
        footer: {text:'Mostrando últimas 30 transações realizadas pelo usuário.'}
    }));

    if (history.length <= 5) return;
    obj.react('⬅');
    obj.react('➡');
    const filter = (reaction,u) => {
        return ['⬅','➡'].includes(reaction.emoji.name) && u.id == msg.author.id;
    }
    async function waitForRR() {
        try {
            var reactions = await obj.awaitReactions(filter, { max: 1, time: 50000, errors: ['time'] });
            if(!exhaust(1000)) return waitForRR();
            reactions.first().users.remove(msg.author);
            if(reactions.first().emoji.name == '⬅') {
                if (pag !== 10) pag = pag - 10;
                update_pages();
                obj.edit({embed: Embed({
                    title: 'Transações de ' + user.tag,
                    description: `${display.join('\n')}`,
                    footer: {text:'Mostrando últimas 30 transações realizadas pelo usuário.'}
                })});
            } else {
                if ((pag + 1) <= history.length) pag = pag + 10;
                update_pages();
                obj.edit({embed: Embed({
                    title: 'Transações de ' + user.tag,
                    description: `${display.join('\n')}`,
                    footer: {text:'Mostrando últimas 30 transações realizadas pelo usuário.'}
                })});
            }
            waitForRR();
        } catch(err) {
            console.log(err);
            return;
        }
    }
    waitForRR();
}
    
as();