//votar,voto//
interval(2);
msg.lineReply(Embed({
    color:'#c680ff',
    description:`Olar ${member} ,
    Acessa aqui pra votar <:peepoPoppy:826929996664406057> 
https://fadinha.site/votar`
}));