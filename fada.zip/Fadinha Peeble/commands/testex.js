//teste//

interval(5);

let button = new MessageButton()
.setStyle('url')
.setURL('https://fadinha.site/comandos') 
.setLabel('Comandos'); 

let button2 = new MessageButton()
.setStyle('url')
.setURL('https://discord.gg/RW773dSMZa') 
.setLabel('Suporte');

let button3 = new MessageButton()
.setStyle('url')
.setURL('https://fadinha.site/add') 
.setLabel('Invite');

let row = new disbut.MessageActionRow().addComponents(button, button2, button3);
msg.channel.send(Embed({
  title:'Fadinha Help!',
  color:'#c680ff',
  description: `
  Olar ${member}
  Eu sou a **${client.user.username}**! meu prefixo é o \`-\`

  Sou um bot com foco principal na diversão de todos com jogos de apostas.

  No meu website é fácil encontrar todos os meus recursos! <:GivePLZ:862916571924135946>`,
  fields: [{
    name: '\u200B',
    value: ':pencil: **Lista de comandos**\nhttps://fadinha.site/comandos \n\n<:moelda:868455091169017866> **Minha Loja**\n https://fadinha.site/loja\ \n\n:closed_book: **Dashboard**\n https://fadinha.site/dashboard',
    inline: true
  }, {
    name: '\u200B',
    value: ':white_check_mark: **Link de invite**\n https://fadinha.site/add \n\n :closed_book: **Minhas regras**\n https://fadinha.site/regras \n\n :placard: **Tem alguma dúvida?** \n [Servidor Suporte](https://discord.gg/RW773dSMZa)',
    inline: true
    }
  ]
}), row);