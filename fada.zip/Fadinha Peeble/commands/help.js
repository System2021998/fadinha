//ajuda,painelcontrole,loja,db,dashboard,regras,background,backgorounds//

interval(5);

msg.lineReply(Embed({
  title:'Fadinha Help!',
  color:'#c680ff',
  description: `Olar ${member}
Eu sou a **${client.user.username}**! meu prefixo é o \`-\`

Sou um bot com foco principal na diversão de todos com jogos de apostas.

No meu website é fácil encontrar todos os meus recursos! <:GivePLZ:862916571924135946>`,
  fields: [{
    name: '\u200B',
    value: ':pencil: **Lista de comandos**\nhttps://fadinha.site/comandos \n\n <:moelda:868455091169017866> **Minha Loja**\n https://fadinha.site/loja\ \n\n :park: **Veja seu dashboard**\n https://fadinha.site/dashboard',
    inline: true}, {
    name: '\u200B',
    value: ':white_check_mark: **Meu link de convite**\n https://fadinha.site/add \n\n :closed_book: **Minhas regras**\n https://fadinha.site/regras \n\n :placard: **Tem alguma dúvida?** \n [Servidor Suporte](https://discord.gg/RW773dSMZa)',
    inline: true
  }]
}));