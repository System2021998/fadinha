interval(2);

if (msg.author.id == '131296127285723137' || msg.author.id == '132196978003017729' || msg.author.id == '326547662641823744') {

    const { inspect } = require("util");
    let result;

    try {
        result = inspect(eval(msg.content.slice(5,msg.content.length)), { depth: 0 })
    } catch(e) {
        result = "There was an error while evaluating: " + e
    }
    let embed = new Discord.MessageEmbed().setDescription(`\`\`\`js\n${result.replace(`${client.token}`, "XXxXxxXXxXxXXXxxxxXXxxXXxXxXXxxXXXXxX")}\n\`\`\``).setColor('#49a657');
    msg.channel.send(embed);
}