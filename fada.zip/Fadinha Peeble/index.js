/*
Fadinha JS
- Este projeto foi feito em puro node.
- Não altere nada aqui sem devida confirmação de alterações passadas.
- Criado por Bad.
*/

// Constatações
const { strict } = require('assert');
var fetch = require('node-fetch');
const Discord = require('discord.js');
var fs = require('fs'); 
var sql = require('mysql2/promise');
var reply = require('discord-reply');
const prettyMilliseconds = require('pretty-ms');
const { Webhook } = require('discord-webhook-node');
const { MessageButton } = require("discord-buttons");
const { get } = require('http');
var prefix = '-'; // Você pode alterar o prefixo da fada aqui.
// Conexão e constatação de cliente.
const client = new Discord.Client({fetchAllmembers: true, shardCount: 7});
const disbut = require('discord-buttons');
disbut(client);

var con
async function connect() {
try {
    con = await sql.createConnection({ 
        host: 'xxxxxxxx', // host sql
        user: 'xxxxxxxx', // user do sql
        database: 'xxxxxxxx', // nome da DB na SQL
        password: 'xxxxxxxx' // senha do user na SQL
    })
    console.log('[SQL] Iniciado!')
} catch(err) {
    console.log(err)
}

}
connect();

// Funções e Armazenamento
eval(fs.readFileSync('utils.js','utf8'))
function storeGlobal (tag,value) {
    this.data[tag] = value;
    fs.writeFileSync('globalDB.json',JSON.stringify(this.data))
}
function gStoreAll() {
    fs.writeFileSync('globalDB.json',JSON.stringify(this.data))
}
function storeUser (id,tag,value) {
    if (!this.data[id]) this.data[id] = {};
    this.data[id][tag] = value;
    fs.writeFileSync('userDB.json',JSON.stringify(this.data))
}
function getDBUser (id,tag) {
    if (!this.data[id]) this.data[id] = {};
    if (!this.data[id][tag]) return false;
    return this.data[id][tag]
}
var GlobalDBData = JSON.parse(fs.readFileSync('globalDB.json','utf8'));
var UserDBData = JSON.parse(fs.readFileSync('userDB.json','utf8'));
function reloadGlobal() {
    this.data = JSON.parse(fs.readFileSync('globalDB.json','utf8'))
}
function reloadUser() {
    this.data = JSON.parse(fs.readFileSync('userDB.json','utf8'))
}
var tempDB = {}
var globalDB = {
    store: storeGlobal,
    reload:reloadGlobal,
    storeAll: gStoreAll,
    data: GlobalDBData
}
var userDB = {
    store: storeUser,
    reload:reloadUser,
    data: UserDBData,
    get: getDBUser
}
// Eventos
client.on('ready', () => {
    console.log('[BOT] Iniciado!')
client.hook = new Webhook("HOOK 1");//webhook de pay
client.hook2 = new Webhook("HOOK 2");//webhook de bet
client.hook3 = new Webhook("HOOK 3");//webhook de rifa
client.hook4 = new Webhook("HOOK 4");//webhook de blackjack
client.hook5 = new Webhook("HOOK 5");//webhook de corrida
    setInterval(function() {
    var list = ['-profile | -help','o popo no chão 😅| -help','-help | www.fadinha.site','🏁 -corrida bet | -help','www.fadinha.site | -help','👀 -rifa | -help','🎲 -bet | -help']; // Lista de atividades
    client.user.setActivity(list[Math.floor(list.length * Math.random())],{
  type: "PLAYING",
});
    },15000)
    setInterval(function() {
        eval(fs.readFileSync('utils.js','utf8'))
        rifatt(); // obtém o evento da rifa, que está no arquivo utils.js
    },5000)

})

client.on('message', (msg) => { // Evento da mensagem, toda vez que alguém manda mensagem esse evento é invoado.
    var args = msg.content.split(new RegExp('\\s+')) // Ele tranforma a mensagem numa lista de argumentos (Ex: '-pay user 1000' para "-pay","user","1000")
    var content = args.join('') // obter o conteúdo da mensagem.
    if (content == `<!teste>`) {
        msg.channel.send('testado ks')
        return false
    }
    eval(fs.readFileSync('utils.js','utf8')) // Obter as utilidades que facilitam minha vida! (arquivo utils.js)
    var member = msg.member // Um jeito mais fácil de pegar o membro.
    if (!args[0].includes(prefix)) return false // Se a mensagem não tiver o prefixo ela desiste.
    var cmds = fs.readdirSync('./commands'); // Pegar todos os comandos!
    var cmd = replaceToAlias(args[0].replace(prefix,'').toLowerCase()); // Transforma a mensagem em comando puro (explicado no utils.js)
    if (cmds.indexOf(`${cmd}.js`) >= 0) { // Se o comando existir né... 
        if (inInterval()) return; // Se tiver em cooldown ela desiste.
        dependencies(msg.author).then((dateSQL)=> { // Se os usuários está "ok"
            eval(fs.readFileSync(`./commands/${cmd}.js`,'utf8'))  // inicia o comando!
        })
    }

})

client.on('messageUpdate', (msg_old,msg) => { // Caso a mensagem foi editada ele chama o evento ai em cima!
    if (msg_old.content == msg.content) return; // Se amensagem for a mesma coisa ele deixa queto.
    client.emit('message',msg)
})
// Login
    client.login('bot_token') 