/*
Bem vindo as utilidades!
Aqui eu enfio  tudo que é util e que possa ser usado nos comandos pra simplificar.
Cuidado, se você alterar o nome de alguma função aqui possa ser que algum comando fique sem funcionar
tenha cautela, assim como qualquer comando!
*/

function b64_encode(str) { // transformar texto em base 64
    let buff = Buffer.from(str);
    return buff.toString('base64');
}

var shards = ['🍉 Watermelon','🍰 Cake','🥭 Mango','🍓 Strawberry','🥀 Rose','🌻 Sunflower','🥞 Waffle','🍪 Cookie']; // Apelidos fofos para os shards.

function b64_decode(str) { // Transformar base64 em texto
    let buff = Buffer.from(str, 'base64');
    return buff.toString('utf8');   
}

function tw(str) { // Eu sei lá o que diabos é isto, mas é importante deixar.
    if (str.length === 1) {
        return `0${str}`;
    } else {
        return str;
    }
}

async function addTransaction(id,str) { // Adicionar alguma coisa nas transações do usuário.
    var [result] = await con.execute(`SELECT * FROM customer_202582_fadinha.users WHERE id='${id}' LIMIT 1;`);
    var list = !result[0].history ? [] : JSON.parse(b64_decode(result[0].history));
    var dn = new Date();
    var timestamp = `\`[${dn.getDate()}/${dn.getMonth() + 1}/${dn.getFullYear()} ${tw(dn.getHours())}:${tw(dn.getMinutes())}]\``;
    if (list.length >= 30) list.splice(0,1);
    list.push(timestamp + ' ' + str);
    await con.execute(`UPDATE customer_202582_fadinha.users SET history='${b64_encode(JSON.stringify(list))}' WHERE id='${id}' LIMIT 1;`);
}

async function SQLdata (id) { // Obter as informações do usuário padrão na SQL, como moeldas, ip, fcoins etc...
    var [result] = await con.execute(`SELECT * FROM customer_202582_fadinha.users WHERE id='${id}' LIMIT 1;`);
    if (!result[0]) {
        await con.execute(`INSERT INTO customer_202582_fadinha.users (id, moeldas, blacklist, fcoins) VALUES ('${id}', '0', 'false', '0');`);
        var [result] = await con.execute(`SELECT * FROM customer_202582_fadinha.users WHERE id='${id}' LIMIT 1;`);
        return result;
    } else {
        return result;
    }

}

function needToDaily(user) { // Checa se o user pegou o daily ou não.
    if (typeof(user) == 'string') {
        user = client.users.cache.get(user);
    }
    if (!user.data) return false;
    if (!user.data.timestamp) return false;
    if (Number(user.data.timestamp) > Date.now()) return true;
}

function vqtd(str){ // Transforma por exemplo "20k" em 20.000
    var t = String(str);
    if(typeof(t) == 'string' && t.endsWith('kk')) {
        t = t.split('kk').join('');
        t = Number(t) * 1000000;
    }
    if(typeof(t) == 'string' && t.endsWith('k')) {
        t = t.split('k').join('');
        t = Number(t) * 1000;
    }
    if (typeof(t) == 'string' && t.includes('k')) Number(t.split('k').join(''));
    return t;
}

async function dependencies(user) { // Checa se o usuário tem todas as dependências.
    var date = Date.now();
    var dsl = await SQLdata(user.id);
    user.data = dsl[0];
    return Date.now() - date;
}

function temp(item) { // Obter... quê?
    return JSON.parse(JSON.stringify(item));
}

function getCountByItem(array, item) { // Ignore.
    var arr = array;
    let count = 0;
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] == item) {
            count++;
        }
    }
    return count;
}

function Embed(info) { // Cria uma embed mais fácil pro meu gosto.
    if (info.thumbnail) {
        info.thumbnail = {url: info.thumbnail}
    }
    if (info.image) {
        info.image = {url: info.image}  
    }
    var emb = new Discord.MessageEmbed(info);
    return emb;
}

function p (str) { //Transforma o texto "20000000" em "20.000.000"
    if(typeof(str) == 'string') str = Number(str);
    return str.toLocaleString('pt-br');
}

function rand(min,max) { // Obtém um numero aleatorio
    if (!max) {
        max = min;
        min = 0;
    }
    return Math.floor(Math.random() * (max - min)) + min;
}

function exhaust(ms,id) { // Um exaustor, ele dá um cooldown para confirmar pays, corridas, blackjacks e etc, ele é super importante!
    if (!ms) ms = 1500;
    if (!id) id = msg.author.id;
    if (!tempDB[id]) {
        tempDB[id] = {}
    }
    if(!tempDB[id]['ex']) {
        tempDB[id]['ex'] = Date.now() + (ms);
        return true;
    }
    if (tempDB[id]['ex'] >  Date.now()) {
        console.log(`[ 🔐 ] Exaustor em intervalo: ${tempDB[msg.author.id]['ex'] - Date.now()}ms`);
        return false;
    }  else {
        tempDB[id]['ex'] = Date.now() + (ms);
        return true;
    }
}

function interval(s) { // Define o intervalo de cada comando em segundos
    if (!tempDB[msg.author.id]) {
        tempDB[msg.author.id] = {}
    }
    if(!tempDB[msg.author.id][cmd]) {
        tempDB[msg.author.id][cmd] = Date.now() + (s * 1000);
        return true;
    }
    if (tempDB[msg.author.id][cmd] >  Date.now()) {
        return false;
    }  else {
        tempDB[msg.author.id][cmd] = Date.now() + (s * 1000);
        return true;
    }
}

function inInterval() { // Checa se o usuário está em intervalo de comandos.
    if (!tempDB[msg.author.id]) return false;
    if (!tempDB[msg.author.id][cmd]) return false;
    return (tempDB[msg.author.id][cmd] >  Date.now());
}

async function getUserInArgs(str,msg,canAuthor,canBot) { // Pega os usuários da mensagem.
    var args = str.split(' ');
    if (args.length === 1) {
        if (canAuthor) {
            return msg.author;
        } else {
            return false;
        }
    }
    var mentions = msg.mentions.members.array();
    if(mentions.length > 0) {
        if (mentions[0].id == msg.author.id && !canAuthor) return false;
        if (mentions[0].user.bot && !canBot){
            return false;
        } else {
            return mentions[0].user;
        }
    } else {
        var args = str.split(' ');
        var user = false;
        var promises = args.map(async (arg) => {
            if (!isNaN(arg)) {
                try {
                    var u = await client.users.fetch(arg);
                    user = u;
                    return;
                } catch (err) { console.log("Erro na função getUserInArgs" + err); }
            }
        });
        await Promise.all(promises);
        if (user.bot && !canBot){
            return false;
        } else {
            return user;
        }
    }
}

function replaceToAlias(str){ // Transforma uma alias no nome correto do comando (Ex: bj em blackjack.)
    for (var i = 0; i < cmds.length; i++) {
        var icm = fs.readFileSync(`./commands/${cmds[i]}`,'utf8');
        if (icm.startsWith('//')) {
            var list = (icm.split('//')[1]).split(',')
            for (var b = 0; b < list.length; b++) {
                str = str.replace(list[b],cmds[i].replace('.js',''))
            }
        }
    }
    return str;
}

async function isImageURL(url) { // checa se a url é uma imagem 100%.
    try {
        var f = await fetch(url);
        var tx = await f.text();
        return (tx.includes('PNG') || tx.includes('JFIF') || tx.includes('Exif') || tx.includes('GIF'));
    } catch (err) {
        console.log("Erro na função isImageURL" + err);
        return false;
    }
}

async function getImage() { // Obtém  imagens na mensagem.
    var url;
    if (msg.attachments.array()[0]) {
        url = msg.attachments.array()[0].url;
        if (url.endsWith('png') || url.endsWith('jpg') || url.endsWith('jpeg') || url.endsWith('gif')) {
            return url;
        } else return false;
    } else {
        var u = await getUserInArgs(msg.content,msg,false,true);
        if (u !== false) {
            return u.displayAvatarURL({size: 512, format: 'png'})
        } else if (args[1]) {
            var i = await isImageURL(args[1]);
            if (!i) return false;
            return args[1];
        } else {
            return false;
        }
    }
}

async function rifatt() { // Evento da rifa que é chamado a cada 5 segundos, não mexe no que não sabe.
    if(!globalDB.data['rdate']) globalDB.store('rdate', Date.now() + 3600000);
    if (globalDB.data['rdate'] < Date.now()) {
        if(!globalDB.data['rtickets']) globalDB.store('rtickets',[]);
        if(!globalDB.data['rusers']) globalDB.store('ruseras',[]);
        if (globalDB.data['rusers'].length > 1) {
            var winnerID = globalDB.data['rtickets'][rand(0,globalDB.data['rtickets'].length - 1)]
            try {
                var user = await client.users.fetch(winnerID);
                var rsql = await SQLdata(winnerID);
                var len = globalDB.data['rtickets'].length
                var lenusers = globalDB.data['rusers'].length;
                globalDB.store('rusers',[]);
                globalDB.store('rdate', Date.now() + 3600000);
                function tg(str) {
                    if (str.includes('.gg/')) {
                        return 'User impróprio#0000';
                    }
                    if (str.includes('+55')) {
                        return 'User impróprio#0000';
                    }
                    if (str.includes('discord')) {
                        return 'User impróprio#0000';
                    }
                    return str;
                }
                globalDB.store('rlastwinner',tg(user.tag));
                globalDB.store('rlastwinnerid',tg(user.id));
                globalDB.store('rlastprize',(len * 190));
                globalDB.store('rtickets',[]);
                client.hook3.send(`👑 ${user} | \`${user.id}\` ganhou ${len * 190} moeldas em rifa.`);
                await con.execute(`UPDATE customer_202582_fadinha.users SET moeldas=moeldas+'${(len * 190)}' WHERE id='${user.id}' LIMIT 1;`);
                await addTransaction(user.id,`📥 Ganhou ${len * 190} moeldas em rifa`);
                user.send(Embed({
                    title:'Ganhador(a) Da rifadinha!',
                    color:'#19e33b',
                    thumbnail:user.displayAvatarURL({dynamic:true}),
                    description:`Parabéns, **${user.username}**! Você ganhou a rifadinha (:
Com ${lenusers} pessoas, ${len} tickets, você ganhou **${len * 190}** Moeldas!
*Espero te ver ganhando na rifa novamente, hehe*`
                }));
            } catch(err) { console.log("Erro na função rifatt" + err); }
        } else {
            globalDB.store('rdate', Date.now() + 3600000);
        }
    }
}